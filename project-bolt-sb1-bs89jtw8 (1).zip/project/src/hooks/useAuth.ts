import { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { data, error };
  };

  const signUp = async (email: string, password: string, name: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (data.user && !error) {
      // Create employee record
      const { error: employeeError } = await supabase
        .from('employees')
        .upsert([
          {
            id: data.user.id,
            name,
            email,
          },
        ], {
          onConflict: 'id'
        });
      
      if (employeeError) {
        console.error('Error creating employee record:', employeeError);
      }
    }

    return { data, error };
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      
      // Clear local storage as backup
      localStorage.clear();
      sessionStorage.clear();
      
      return { error };
    } catch (error) {
      console.error('Sign out error:', error);
      
      // Clear local storage as fallback
      localStorage.clear();
      sessionStorage.clear();
      
      return { error: error as Error };
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
  };
};